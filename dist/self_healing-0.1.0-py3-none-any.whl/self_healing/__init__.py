# __init__.py

from .core import debug_code, check_code

__all__ = ["debug_code", "check_code"]

__version__ = "0.1.0"
